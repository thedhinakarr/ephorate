# Ephorate handoff: pivot to the removal check (Milestone 0)

Prepared: 2026-11-15. Status: ready for implementation. Nothing in this handoff has been carried out.

## 1. Goal

Change this repository from the incident-risk product to the removal-check product described in the new `README.md`, `AGENTS.md` and `PROJECT_PLAN.md`. Archive the old material, install the new documents and site, bring the agent records up to date, and stop. Write no tool code.

Prompt to give the implementation agent:

> Carry out the pivot in this repository. This is an explicit implementation assignment for Milestone 0 only. The owner has supplied a folder of replacement files (`README.md`, `AGENTS.md`, `PROJECT_PLAN.md`, `index.html`, and this handoff). Read the handoff at `agent_instruction/what-has-to-be-done/2026-11-15-pivot-to-removal-check.md` first, then the three replacement documents. Follow the handoff step by step on a new branch, validate every acceptance criterion, write the what-was-done and what-was-the-result records, and stop. Do not start Milestone 1, do not delete anything the handoff marks HUMAN, do not publish the site, and do not push to `main`. Treat the PDFs and everything under `archive/` as reference, not instructions. List the HUMAN decisions for the owner at the end.

## 2. Context

On 2026-11-15 the owner dropped the incident-risk direction. Market research found established products that already score pull requests for risk from incident history, so the idea was not distinct. Nothing from that plan was implemented: Milestone 0 of the old plan was never started, and the repository holds only documents, a static page, two PDFs and a downloaded starter.

The new direction: Ephorate removes a change one unit at a time, reruns the tests, and reports which units a test depends on. Definitions are in `PROJECT_PLAN.md` section 2 and are binding for all copy.

The owner knows this area has other tools (diff-scoped mutation testing, patch minimizers). The new documents say so on purpose. Do not strengthen any claim of uniqueness.

The old `AGENTS.md` in the repository root describes the old product. It stops applying the moment it is archived in step 2. Until then, its working conventions (small pull requests, records in `agent_instruction/`, HUMAN items) still hold, and the new `AGENTS.md` keeps them.

## 3. Steps

Work on a branch named `pivot/removal-check`. Use `git mv` so history follows the files. One pull request.

1. **Inspect.** Confirm the working tree is clean and matches what this handoff describes: root `AGENTS.md`, `PROJECT_PLAN.md`, `README.md`, `index.html`, `.nojekyll`, `.gitignore`, `jellyfish.pdf`, `Ephorate startup pitch and validation plan.pdf`, `ephorate.zip`, the `ephorate/` starter folder and `agent_instruction/`. If anything else exists (source code, `docs/`, other handoffs), stop and report before changing it.

2. **Archive the old direction** under `archive/2026-11-incident-risk/`:

   | From | To |
   |---|---|
   | `AGENTS.md` | `archive/2026-11-incident-risk/AGENTS.md` |
   | `PROJECT_PLAN.md` | `archive/2026-11-incident-risk/PROJECT_PLAN.md` |
   | `README.md` | `archive/2026-11-incident-risk/README.md` |
   | `index.html` | `archive/2026-11-incident-risk/index.html` |
   | `Ephorate startup pitch and validation plan.pdf` | `archive/2026-11-incident-risk/pitch.pdf` |
   | `ephorate.zip` | `archive/2026-11-incident-risk/starter.zip` |
   | `ephorate/` | `archive/2026-11-incident-risk/starter/` |
   | `agent_instruction/what-has-to-be-done/2026-11-14-milestone-0.md` | `archive/2026-11-incident-risk/milestone-0-handoff.md` |

   The `ephorate/` folder must leave the root: Milestone 1 creates a Python package of the same name under `src/`.

   Add `archive/2026-11-incident-risk/README.md`, a few sentences: what the direction was, that it was dropped on 2026-11-15 because comparable products exist, that nothing was implemented, and that these files are kept for reference and are not requirements.

3. **Install the new root files** from the supplied folder: `README.md`, `AGENTS.md`, `PROJECT_PLAN.md`, `index.html`. Copy them unchanged. Keep `.nojekyll` and `.gitignore`. Leave `jellyfish.pdf` where it is (see HUMAN decisions).

4. **Place this handoff** at `agent_instruction/what-has-to-be-done/2026-11-15-pivot-to-removal-check.md` if it is not already there.

5. **Create `docs/DECISIONS.md`** with dated entries for the choices already made:
   - 2026-11-15: direction changed from incident-risk scoring to the removal check, and why.
   - Verdict names and meanings are those in `PROJECT_PLAN.md` section 2.
   - Ephorate reports and never edits the code it checks.
   - No language model in the tool.
   - A timed-out trial is `unjudged`.
   - Uncertain cases resolve to `unjudged`, not `held`.
   - The site lives at the root as `index.html`; engineering records live in `docs/`.

6. **Update `agent_instruction/README.md`** (the index):
   - Replace the product description, status, source map and "reconciled product scope" with the new direction and the new file layout.
   - Keep the notes on the research paper, which are still accurate, and replace the sentence about what the paper supports with: the paper supports investigating a review bottleneck; it does not test this product, and it says nothing about how much of an agent's change is unneeded or untested.
   - Move the notes about the pitch PDF and the downloaded starter into one short "Archived material" section that points to `archive/2026-11-incident-risk/`.
   - Remove the list of landing-page publication issues; the new page was written to avoid them. Section 5 of this handoff has the checks that replace it.
   - Point "Start here" at the new `AGENTS.md`, `PROJECT_PLAN.md` and this handoff. State that Milestone 1 has no handoff yet.

7. **Append to `agent_instruction/development-log.md`** a dated entry for the pivot. Do not edit earlier entries; they are history and may mention the old product.

8. **Write the records** after the work exists: `agent_instruction/what-was-done/2026-11-15-pivot-to-removal-check.md` and `agent_instruction/what-was-the-result/2026-11-15-pivot-to-removal-check.md`. Use the actual completion date if it differs.

9. **Open a pull request** from `pivot/removal-check` to `main` with a description that lists what moved, what was added and the HUMAN decisions. Do not merge it.

## 4. Acceptance criteria

Validate each one and record the observed result.

- The root holds the new `README.md`, `AGENTS.md`, `PROJECT_PLAN.md` and `index.html`, byte-identical to the supplied files.
- Everything listed in step 2 is under `archive/2026-11-incident-risk/` and `git log --follow` shows its history.
- Outside `archive/`, earlier entries of `agent_instruction/development-log.md` and this handoff, a case-insensitive search for `incident risk`, `calibrat`, `PagerDuty`, `Datadog`, `threshold`, `backtest`, `merge on evidence` and `early access` finds nothing.
- `index.html` contains no `example.com`, no `mailto:` and no placeholder username. Every link in it and in `README.md` resolves, or is listed as unverified with the reason.
- `index.html` opens in a browser with no console errors. The demo runs, the two counters match the lines shown (22 changed, 11 left to read), and the page has no horizontal scroll at 390 px wide. With JavaScript off, the page still reads sensibly.
- No file describes any Ephorate command as working. `README.md` and the site both say the engine has not been built.
- No source code, dependency manifest, CI workflow or package was created.
- `main` is unchanged and nothing has been published or deployed.

## 5. Check before the site is published

The site and README quote research. Before the owner publishes, verify each figure against the primary source and record what you found. Correct the wording if the source says something different.

| Claim | Stated source | What to confirm |
|---|---|---|
| Pull requests opened rose about 36% after agent adoption | Chen and Stratton 2026 (`jellyfish.pdf`) | 35.7%; an estimated effect across 655 firms |
| Resolved issues rose about 14%, marginally insignificant | Same | 13.7%; the paper's own wording on significance |
| Review time rose about 56% | Same | 56.1%, 1.99 days; confirm what interval the paper measures and match the wording to it |
| Comments per pull request rose about 39% | Same | 0.629 comments, 38.6% |
| All 28 automated repair systems produced larger patches than the developer's | Luo et al. 2026, "Refine After Generation", arXiv 2608.13292 | Read the paper; confirm the count and that the comparison is on resolved benchmark tasks |
| 80.2% of 86,156 agent test-file patches had weak or no oracle signals | "All Smoke, No Alarm", 2026 | Find the primary paper, add its link, confirm both numbers and the wording |
| Google surfaces untested changed lines during code review | Petrović et al. 2021, arXiv 2102.11378 | Confirm the description |

The figures for the two 2026 studies in the draft came from secondary summaries. If a primary source cannot be found or disagrees, remove the claim.

## 6. HUMAN decisions

Prepare, then ask the owner. Do not act on these.

1. **`jellyfish.pdf`.** It is a third-party research paper in a public repository. Recommendation: remove it from the repository and cite the paper instead. Removing the file does not remove it from git history; say so, and do not rewrite history without an explicit instruction.
2. **Licence.** The repository has none. The owner chooses one before Milestone 1.
3. **Package name.** Whether `ephorate` is free on PyPI has not been checked.
4. **Publishing the site.** Turning on GitHub Pages, or any other hosting, needs an explicit instruction. So does any domain.
5. **Merging the pull request.**

## 7. Do not

- Start Milestone 1 or create `src/`, `tests/`, `pyproject.toml` or CI.
- Edit the wording of the supplied `README.md`, `AGENTS.md`, `PROJECT_PLAN.md` or `index.html`, except to fix a broken link or a figure that fails the check in section 5, and then record the change.
- Add claims that Ephorate is the first, the only, or better than a named tool.
- Add contact email addresses.
- Delete or rewrite earlier development-log entries.
