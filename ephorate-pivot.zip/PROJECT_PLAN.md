# Ephorate project plan

Version of 2026-11-15. This plan replaces the incident-risk plan now in `archive/2026-11-incident-risk/`.

## 1. Purpose

Coding agents write changes faster than people can review them. Their changes tend to include code the task did not need and tests that check little. A reviewer cannot see either by reading a diff.

Ephorate answers one question for each piece of a change: **which test fails if this is removed?** The answer sorts the change into code a test depends on and code nothing depends on. An agent clears the second pile before review. A reviewer reads the tests and whatever is left.

What must be true for this to be worth building, and is not yet known: on real agent-written pull requests, a meaningful share of changed lines comes out `loose` or `inert`, and `held` verdicts are mostly backed by tests that check real behaviour. Milestone 2 measures this. Everything after it depends on the result.

## 2. Definitions

These words are used the same way in code, reports, documentation and the site.

**Change.** The difference between a base commit and a head commit. The base defaults to the merge base of the head with the default branch.

**Judge file.** A changed file that holds tests or test configuration: files matched by the project's test patterns, `conftest.py`, test-runner configuration, CI workflow files. Judge files are never split or removed.

**Subject file.** A changed source-code file in a supported language that is not a judge file.

**Other file.** Any other changed file: documentation, configuration, data, migrations, lock files, generated files.

**Unit.** The smallest piece of a subject file's change that Ephorate removes on its own. In Milestone 1 a unit is one hunk of `git diff -U0`. Milestone 4 splits large hunks and new files into smaller units along definition boundaries.

**Removal trial.** Build a scratch copy of the head with one unit, or one group of units, reverted to its base state. Run tests. Read the results.

**Baseline.** The test results on the unmodified head. The baseline must pass. It is run twice; a test whose outcome differs between the two runs is flaky and is ignored in every trial.

**Structural failure.** A trial result where the project cannot be loaded or a test dies before reaching a check: collection errors, syntax errors, and test failures whose exception type is in the structural list (initially `ImportError`, `ModuleNotFoundError`, `NameError`, `AttributeError`, `SyntaxError`, `IndentationError`). A structural failure shows that other code refers to the unit, not that any behaviour is tested.

**Witness.** A test that passed at baseline and, in a removal trial, fails without a structural failure.

**Verdicts.** Every unit ends with exactly one.

| Verdict | Condition |
|---|---|
| `held` | A removal trial of the unit, or of the smallest group containing it, has at least one witness. The witnesses are recorded. |
| `loose` | A removal trial of the unit, or of the smallest group containing it, runs with no failure of any kind. The reason is recorded as either "no test runs these lines" or "tests run these lines and pass without them". |
| `inert` | The subject file parses to an identical syntax tree with and without the unit. No trial is run. |
| `unjudged` | Anything else: the unit sits in an other file, the trial timed out, the unit could not be isolated within the trial budget, or the language is unsupported. The reason is recorded. |

**Group.** A set of units removed together because removing one alone gives a structural failure.

**Idle test.** A test added or modified by the change that still passes when every subject unit is removed. It does not depend on the change.

**Reading list.** The units with verdict `loose` or `unjudged`, the idle tests, and any judge file that the change modified or deleted (as opposed to added).

## 3. How a check runs

1. Resolve base and head. Refuse to run on a dirty working tree unless told otherwise; never modify it.
2. Classify changed files as judge, subject or other.
3. Split subject files into units.
4. Run the baseline twice in a scratch copy of the head. Stop with a clear message if it fails.
5. Mark `inert` units by comparing syntax trees.
6. For each remaining unit, run a removal trial and classify the result as witness found, clean pass, structural failure or timeout.
7. Put units with structural failures into groups and try the groups (section 4).
8. Run the idle-test trial: all subject units removed, judge files kept.
9. Write the report: terminal summary, JSON file, exit code.

Exit codes: `0` when the check ran; `1` when the check ran and a `--fail-on` condition matched (`loose`, `unjudged`, `idle`); `2` for usage errors and baseline failure.

## 4. Design notes

**Scratch copies.** Trials run in git worktrees or temporary checkouts created from the head commit, one per parallel job, with the unit's hunk reverse-applied. They are removed at the end, including after errors and interrupts.

**Reading test results.** Ephorate reads JUnit XML, which pytest and most other runners can emit, so that later runners need only a small adapter. The pytest adapter adds the flags to produce the report and maps each test case to pass, fail (with exception type), error or skipped.

**Grouping.** Milestone 1 makes one extra trial with all structurally failing units removed together. Milestone 4 replaces this with a delta-debugging search (Zeller's ddmin) for the smallest removable groups, within a trial budget. Units still not isolated when the budget runs out are `unjudged`.

**Test selection.** From Milestone 3, the baseline records which tests execute which lines (coverage contexts), and a trial runs only the tests that execute the unit's lines or, for a pure deletion, the enclosing definition. A unit no test executes is `loose` without a trial. Selection can miss tests that depend on a unit indirectly, so `--full` turns it off and the acceptance tests compare both modes.

**Timeouts.** A trial is stopped after a multiple of the baseline duration. A timed-out unit is `unjudged`. (Mutation testing usually counts a timeout as detected; this plan takes the cautious reading. Revisit with replay data.)

**Cost control.** A cap on units per run, a wall-clock budget, parallel jobs, and a cache keyed by the tree hash of each trial copy and the test command.

**Report.** One JSON document with a schema version: the change (base, head, files), the baseline (counts, flaky tests), each unit (file, line range, verdict, reason, witnesses, group), idle tests, modified judge files, and timings.

**Configuration.** Optional `.ephorate.toml`: test command, patterns for judge, subject and skipped files, structural exception list, timeout factor, unit cap, job count.

## 5. Stack

- Python, developed on the version pinned in `.python-version`, supporting the Python versions still maintained upstream. Check current versions before pinning.
- `uv` for the project, `ruff` for lint and format, `mypy` in strict mode, `pytest` for Ephorate's own tests.
- Run-time dependencies: the standard library. `argparse` for the command line, `subprocess` for git and test runners, `ast` for the inert check, `xml.etree` for JUnit reports. The project being checked needs `coverage` for test selection; Ephorate detects it and falls back to full runs.
- Packaged with a build backend and a `[project.scripts]` entry so `ephorate` is a command. PyPI name availability is unverified (**HUMAN**).
- The GitHub Action is a composite action in this repository that installs the tool and posts one comment through the GitHub API.
- The site is one static `index.html` at the repository root with no build step.

## 6. Milestones

Each milestone has a handoff file, acceptance criteria and a report. Stop after each one.

### Milestone 0: Reset the repository

Archive the incident-risk material, install the new `README.md`, `AGENTS.md`, `PROJECT_PLAN.md` and `index.html`, bring `agent_instruction/` up to date, and create `docs/DECISIONS.md`. No tool code. The handoff is `agent_instruction/what-has-to-be-done/2026-11-15-pivot-to-removal-check.md`.

### Milestone 1: The engine, on fixtures

Build `ephorate check` for Python projects tested with pytest.

- Project skeleton, lint, types, tests, CI running the same commands.
- File classification, hunk units, scratch copies, baseline run twice, flaky detection.
- Removal trials with full test runs, JUnit reading, structural-failure detection.
- `inert` by syntax-tree comparison. One grouped trial for structurally failing units. The idle-test trial.
- Terminal summary and JSON report, exit codes.
- Fixture repositories built by script, each with a known correct verdict for every unit: a needed and tested line, an unneeded branch, a needed but untested line, a comment-only edit, a new helper plus its caller, a rename across two files, a configuration edit, a flaky test, a test that passes without the change.

Accepted when every fixture gets its expected verdicts, the user's working tree is byte-identical before and after every run including interrupted ones, and two runs on the same input give identical JSON apart from timings.

### Milestone 2: Replay on real pull requests, then decide

Measure what Ephorate says about real agent-written changes.

- **HUMAN:** approve the selection rule and the list of repositories before any are cloned. Public repositories only.
- Write the selection rule down first: merged pull requests authored by coding-agent accounts, in Python projects whose pytest suite runs offline in a few minutes. Aim for at least 30 pull requests across at least 10 repositories.
- Run the Milestone 1 engine on each. Record units, lines and verdict shares, trial counts and run time.
- Audit by hand at least 30 `loose` units (unneeded, needed but untested, or wrongly loose) and at least 30 `held` units (does the witness check real behaviour, or only that something exists).
- Write `docs/REPLAY_REPORT.md` with the method, the numbers, the audit, failures and what could not be run. Link to pull requests; do not copy other projects' code into this repository beyond short quoted lines.

**HUMAN gate.** The owner reads the report and decides whether to continue. The report must state plainly: the median and spread of the share of changed source lines that are `loose` or `inert`, how many audited `loose` units were real findings, and how many audited `held` verdicts rested on shallow tests. If loose and inert lines are rare, or most findings are noise, the honest recommendation is to stop.

### Milestone 3: Speed

Coverage-based test selection with a `--full` switch, parallel trials, the trial cache, unit caps and time budgets. Accepted when selection gives the same verdicts as full runs on every fixture and on the replay set, with the differences, if any, listed and explained.

### Milestone 4: Precision

Delta-debugging groups, units finer than hunks for large hunks and new files, reporting of modified and deleted judge files, tuning of the structural exception list using replay data. Accepted on new fixtures plus a rerun of the replay set with the change in verdicts reported.

### Milestone 5: The agent loop

A stable JSON contract, `--fail-on`, and short instruction files for coding agents (Claude Code, Codex, Cursor) that say: run the check before opening a pull request; for each `loose` unit, delete it or add a test that fails without it; never edit an existing test to change a verdict. Demonstrate on fixture tasks that an agent following the instructions reduces `loose` lines, and record how often it does so by writing shallow tests.

### Milestone 6: GitHub Action

A composite action that runs the check on a pull request and keeps one comment up to date: counts by verdict, the reading list with links to lines, held units folded away with their witnesses. It also writes the job summary and uploads the JSON report. It needs only permission to read the repository and write pull request comments.

### Milestone 7: Reviewer report

`ephorate report --html`: one static file showing the diff with `held` and `inert` units collapsed under their reason and the reading list open. No server, no external requests.

### Milestone 8: A second language

TypeScript with vitest or jest, through the JUnit adapter, with a syntax-tree comparison for `inert`. Decide the parser then and record why.

### Milestone 9: Release

Version 0.1 on PyPI (**HUMAN**), the Action published, documentation complete, a demo repository, and the site updated with the real replay figures in place of the illustration.

## 7. Risks

- **Too little loose code in practice.** Milestone 2 tests this before further investment.
- **Slow or broken test suites.** Many repositories cannot run their tests in minutes. The tool states its requirement up front and fails early with a clear message.
- **Shallow tests written to satisfy the check.** Milestone 5 measures it. The reviewer still reads the tests, and idle-test detection catches the crudest cases.
- **Wrong `held` verdicts from structural failures.** The structural list is a heuristic. The audit in Milestone 2 and the tuning in Milestone 4 exist for this.
- **Existing tools.** Diff-scoped mutation testing and patch minimizers overlap with parts of this. Ephorate does not claim to be alone; its case is the combination, the reading-list output and the agent loop. `README.md` says so and must keep saying so.
- **Agent vendors add it themselves.** Possible. The tool stays small, open and vendor-neutral.
