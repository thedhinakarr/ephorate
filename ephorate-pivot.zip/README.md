# Ephorate

**Every changed line answers to a test, or to you.**

Ephorate takes a code change, removes it one piece at a time, and reruns your tests after each removal. Pieces that make a test fail when removed are held up by that test. Pieces that can be removed with every test still passing are held up by nothing. Coding agents use the result to delete or test the second kind before asking for review. Reviewers use it to see where to start reading.

Repository: [thedhinakarr/ephorate](https://github.com/thedhinakarr/ephorate)

> **Status:** design only. The engine has not been built, and no command below works yet. See [Status](#status).

## Why

Coding agents write code faster than people can review it. A 2026 study of 655 firms estimated that after firms adopted coding agents, pull requests opened rose about 36% and review time from submission to merge rose about 56%, while resolved issues rose about 14% (that last estimate is marginally insignificant). Reviewers are reading more pull requests for each finished piece of work.

Two things make an agent's pull request slow to read:

- **Extra code.** Agents keep changes the task did not need: leftovers from trial and error, defensive branches, unrequested cleanups.
- **Tests that prove little.** The agent writes the tests as well as the code, so "all tests pass" says less than it used to.

A reviewer cannot see either from the diff, so every line gets read with the same suspicion. Ephorate measures both with one question per piece of the change: *which test fails if this is removed?*

## How it works

1. **Split the change.** Changed source files are split into units. A unit starts as one diff hunk. Changed test files are not split; they are the judges.
2. **Check the baseline.** The test command runs twice on the full change. It has to pass, and tests that flip between runs are set aside.
3. **Remove one unit and run the tests.** This repeats for each unit, in a scratch copy of the repository.
4. **Give each unit a verdict.**

| Verdict | Meaning |
|---|---|
| `held` | With the unit removed, a test that passed now fails on an assertion. The report names the test. |
| `loose` | With the unit removed, every test still passes. It is unneeded, or nothing tests it. |
| `inert` | The unit changes no behaviour: the file parses to the same syntax tree with or without it. |
| `unjudged` | Ephorate cannot tell: not code, removal breaks the build even when grouped, or the trial timed out. |

5. **Report.** A terminal summary, a JSON file for agents and CI, and later a comment on the pull request.

Units that cannot be removed alone (removing one breaks an import, for example) are grouped with the units they depend on and tried together.

Ephorate also runs one trial with every source unit removed and the new tests kept. A new test that still passes does not depend on the change at all and is reported as **idle**.

## What it looks like

Planned interface. Example output, not a real run:

```text
$ ephorate check --base origin/main -- pytest -q

Change    6 units, 22 changed lines in 4 files
Baseline  214 tests passed, run twice, 0 flaky

held      2 units    8 lines   a test fails without them
inert     1 unit     3 lines   comments only
loose     2 units    9 lines   every test passes without them
unjudged  1 unit     2 lines   not code

Read these first
  loose     billing/refund.py:88-90   all 214 tests pass without it
  loose     billing/retry.py:12-17    all 214 tests pass without it
  unjudged  settings.toml:4           not code
```

For a coding agent, the instruction is short: run `ephorate check` before opening a pull request, and for each `loose` unit either delete it or add a test that fails without it.

## What Ephorate does not do

- **It does not edit code.** It reports. A person or an agent decides what to delete. Deleting automatically would be unsafe wherever tests are thin, because untested code that matters looks the same as code that does not.
- **It does not use a language model.** The same change and the same tests give the same verdicts.
- **It does not say a line is correct.** `held` means a test depends on the line. Whether that test asks for the right behaviour is still a reviewer's call.
- **It does not send code anywhere.** It runs where your tests run.

## How it relates to tools you may already use

Ephorate is built on known techniques and is not the only tool in this area.

- **Mutation testing** (Stryker, PIT, cargo-mutants, mutmut and others) makes small edits to code and reports which edits no test notices. Ephorate's removal trial is a coarse form of the same idea, applied to whole pieces of one change and reported as a reading list instead of a score.
- **Patch minimizers** delete the parts of a change that tests do not need. Ephorate runs the same trial and stops at the report.
- **AI reviewers** read the diff and comment. Ephorate reads nothing and comments on nothing; it runs tests.

The removal trial itself goes back to delta debugging (Zeller, 1999) and to work on pseudo-tested code (Niedermayr et al., 2016; Vera-Pérez et al., 2019).

## Limits

- It needs a test suite that passes and runs in minutes. Each unit costs at least a partial test run.
- It says nothing useful about configuration, migrations, infrastructure or most UI work.
- An agent can write a shallow test to make a line `held`. Reviewers still read the tests.
- Whether enough of a typical agent change turns out `loose` or `inert` to matter is not known yet. Milestone 2 measures that on real pull requests before anything else is built.

## Status

| Part | State |
|---|---|
| Design, plan and site | Done |
| Engine: units, removal trials, verdicts (Python and pytest) | Next |
| Replay on real agent pull requests, with a go or no-go decision | Planned |
| Speed: test selection, parallel trials, caching | Planned |
| Agent loop and GitHub Action | Planned |
| Reviewer report, second language, release | Planned |

`PROJECT_PLAN.md` has the milestones. `AGENTS.md` has the rules for coding agents working in this repository.

## Repository layout

```text
README.md            this file
AGENTS.md            standing rules for coding agents
PROJECT_PLAN.md      definitions, design and milestones
index.html           the project site, a single static page
docs/                engineering records (decisions, replay report)
agent_instruction/   handoffs, work records and the development log
archive/             the earlier incident-risk direction, kept for reference
src/ephorate/        the tool (from Milestone 1)
tests/               tests and fixture repositories (from Milestone 1)
```

## The name

The ephorate was Sparta's board of five elected overseers, who could call even the kings to account. It is pronounced EFF-er-it.

## Sources

- Chen and Stratton, "Artificial Intelligence in the Firm: Bottlenecks in Software Production", Harvard University, version of 9 November 2026. Figures above are the paper's estimated effects of AI agent adoption.
- Petrović, Ivanković, Fraser and Just, "Practical Mutation Testing at Scale", IEEE TSE, 2021. https://arxiv.org/abs/2102.11378
- Zeller, "Yesterday, my program worked. Today, it does not. Why?", ESEC/FSE 1999.
- Vera-Pérez, Danglot, Monperrus and Baudry, "A Comprehensive Study of Pseudo-tested Methods", Empirical Software Engineering, 2019. https://arxiv.org/abs/1807.05030
